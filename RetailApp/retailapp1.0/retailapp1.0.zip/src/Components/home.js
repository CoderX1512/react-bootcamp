
import React from "react";

const Home = () => {
    return (
        <div>
            <h1>Welcome to world's largest retail </h1>
            <p1>This is the home page of our retail website.</p1>
        </div>
    );
};

export default Home;